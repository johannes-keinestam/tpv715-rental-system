require_relative "article"

#Describes a jet ski in the rental store. Extends Article.
class JetSki < Article
  def initialize(idNo)
    @rented = false
    @price = 100
    @idNo = idNo
  end

  #Returns the name of the jet ski incl. ID number
  def to_s
    return "Jet Ski #{@idNo}"
  end
end