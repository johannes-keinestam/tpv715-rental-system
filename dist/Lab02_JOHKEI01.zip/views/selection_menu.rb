require_relative "welcome_menu"
require_relative "../data/data_container"

#Menu that displays the product selection, and the rental status for each product.
module SelectionMenu
  #Shows the selection menu in the console
  def SelectionMenu.show
    system "cls"

    #Gets selection list, and list of registered orders
    @selection = DataContainer::get_selection
    @orders = DataContainer::get_orders

    #Puts non-rented products from selection, and rented products from order list
    #into array. This way it can display the rental data (customer, time).
    printable_selection = Array.new
    @selection.each_value do |product_category|
      product_category.each { |product| printable_selection.push("#{product}, available") unless product.is_rented? }
    end
    @orders.each_value do |customer|
      customer.each { |order| printable_selection.push(order.to_s) if order.is_active? }
    end
    
    #Sort: sorts alphabetically up until the first number (which is the id-number
    #of the product), which is sorted numerically instead. This prevents sorting
    #like: "Boat 1", "Boat 10", "Boat 11", "Boat 2"
    printable_selection.sort! do |a,b|
      if a.split(/\d+/)[0] == b.split(/\d+/)[0]
        a.scan(/\d+/)[0].to_i <=> b.scan(/\d+/)[0].to_i
      else
        a <=> b
      end
    end

    puts "============================================================"
    puts "Product selection:"
    printable_selection.each_index { |x| puts "    #{x+1}. #{printable_selection[x]}" }
    puts "============================================================"
    puts "Press Enter to return"

    gets
    WelcomeMenu::show
  end

end
