require_relative "welcome_menu"
require_relative "../data/data_container"

#Menu for displaying a list of all customers who have at any time rented a product.
module CustomerListMenu
  #Shows the customer list menu in the console
  def CustomerListMenu.show
    system "cls"

    #Gets all customers from DataContainer
    @customers = (DataContainer::get_orders).keys.sort

    puts "============================================================"
    puts "Customer registry:"
    @customers.each { |customer| puts "    #{customer}" }
    puts "============================================================"
    puts "Press Enter to return"

    gets
    WelcomeMenu::show
  end
end
