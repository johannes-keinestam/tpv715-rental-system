#Describes an order placed in the system. 
class Order
  def initialize(product, customer, date)
    @customer, @product, @date = customer, product, date
  end

  #Returns a string presenting an active order. Used in "Return menu"
  def to_s
    return "#{@product}, rented by #{@customer} on #{@date}"
  end
end
		