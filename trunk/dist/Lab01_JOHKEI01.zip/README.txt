﻿README - Ruby Beach Water Sports (Lab 1)
Utkast 1 (2011-06-15)
Skribent: Johannes Keinestam

INSTRUKTIONER:
I Windows-miljö kan programmet köras genom att dubbelklicka på filen main.rb.
Under *nix-miljöer så startas det via terminalen genom kommandot "ruby main.rb".

OM PROJEKTET:
Ruby Beach Water Sports (RBWS) är ett uthyrningssystem för båtar och andra
vattensportartiklar. Syftet med labben är för mig som student att lära mig
använda programmeringsspråket Ruby genom att koda objektorienterat. Programmet
skulle kunna implementeras som ett uthyrningssystem för vilka typer av produkter
som helst. Detta skulle kunna ta sig form som ett onlinesystem eller ett
integrerat system i någon slags uthyrningsterminal.

PROGRAMDESIGN:
RBWS är änsålänge i ett väldigt tidigt utvecklingsstadie. Därför är strukturen
på programmet slarvig. Framtida utveckling kommer röra sig mot ett MVC-liknande
designmönster för att minska kopplingarna mellan programmets delar, men på grund
av projektets förhållandevis begränsade storlek så kommer denna antagligen inte
ske fullt ut med EventHandlers, utan på något simplare och mer kortfattad nivå.
Detta kan dock leta till kopplingar mellan model och view, vilket inte är
önskvärt.

KLASSER:
View-delen i programmet ligger i klassen MenuSystem, som änsålänge är en modul.
Det kan den gott vara, eftersom det inte finns intressa av att skapa fler än
en instans av den. Den innehåller all logik för att skriva ut i konsollen, och
änsålänge är också den klass som sköter logiken för alla utlåningar. Den lösning
jag har nu är att hålla alla utlåningar (instanser av klassen Order) i en array
i denna modul, som sedan kan löpas igenom. Ingen vidare lösning, och detta ska
senare separeras ut.

Just nu finns bara en produkt att hyra (av klassen Boat), men detta ska givetvis
kunna utökas dynamiskt. Tillgängliga produktklasser borde finnas i en lista, så
att dessa kan skrivas ut i menysystemet. Nu är jag inte riktigt säker på vad som
kommer i senare labbar, men det skulle vara trevligt att utöka detta med en
riktig databas så att datan kan sparas, samt ett riktigt GUI.

De andra klasserna är inte mycket att diskutera, eftersom det finns kommentarer
samt att de säger de mesta själv.

UML:
Se senare inlämningar.

CHANGES:
Se senare inlämningar.