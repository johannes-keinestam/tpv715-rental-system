#Class that describes a customer, each having a name and a list of rented
#products (can be empty). Also handles renting/returning of a specific customer's
#products. Not implemented in application (no use for it yet).
class Customer
  def initialize(name)
    @name = name
    @products = Array.new
  end

  def rent_product(product)
    @products.push(product)
  end

  def return_product(product)
    @products.delete(product)
  end
  
  def rented_products
    return @products
  end

  def to_s
    return @name
  end
end
