require_relative "menu_system"

#Main file for launching the program.
#Very basic as of yet, will be extended if MVC-like pattern will be implemented.
MenuSystem.show_welcome