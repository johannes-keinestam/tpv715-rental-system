#Describes a boat. Has no knowledge of the renter, only it's own data which
#as of now is it's ID number, which is randomized. Does not prevent possible
#clashes in ID numbers yet.
class Boat
  def initialize
    @idNo = rand(11)+1
  end

  #Returns the name of the boat incl. ID number
  def to_s
    return "Boat #{@idNo}"
  end
end