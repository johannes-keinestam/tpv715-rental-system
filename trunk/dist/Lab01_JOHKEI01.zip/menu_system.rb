require_relative "order"
require_relative "boat"

#Module for handling the "GUI" parts of the program (as of now the console, but
#a real GUI might be used later, if wanted)
module MenuSystem
  @welcome = ["============================================================",
           "Welcome to the Ruby Beach Water Sports rental system \n\n",
           "Menu:",
           "    1. Rent",
           "    2. Return",
           "============================================================",
           "What do you want to do?",]

  @rent = ["============================================================",
           "Rent:",
           "    1. Boat",
           "    0. Cancel",
           "============================================================",
           "What do you want to rent?"]
  @orders = Array.new

  #Shows the welcome menu in the console.
  def MenuSystem.show_welcome
    #Clears screen, might not work cross-platform
    system "cls"

    puts @welcome
    choice = gets.to_i

    #Handles the input from the user. Easily extendable for later.
    case choice
      when 1 then show_rent
      when 2 then show_return
      else show_welcome
    end
  end

  #Shows the rent menu in the console
  def MenuSystem.show_rent
    system "cls"

    puts @rent
    productNo = gets.to_i

    #Rents the chosen product (only one now). 
    case productNo
      when 1 then product = Boat.new
      else show_welcome
    end

    #Gets user data, saves the order in a list
    puts "Your name:"
    name = gets.chomp
    puts "Rent from date:"
    date = gets.chomp

    @orders.push(Order.new(product, name, date))

    show_welcome
  end

  #Shows the return menu in the console, containing the list of all rented products.
  def MenuSystem.show_return
    system "cls"

    #Menu defined here as of now, because it needs to be changed dynamically.
    puts "============================================================"
    puts "Your current rentals:"
    @orders.each_index {|x| puts "    #{x+1}. #{@orders.at(x)}"}
    puts "    None" if @orders.empty?
    puts "    0. Cancel"
    puts "============================================================"
    puts "Which rental do you want to return?"
    choice = gets.to_i

    #If valid number tried to be deleted, return to welcome menu, otherwise show again
    if choice != 0 and @orders.delete_at(choice-1) == nil
      show_return
    else
      show_welcome
    end
  end
end
